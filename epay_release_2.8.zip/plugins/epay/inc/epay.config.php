<?php
/* *
 * 配置文件
 */

//支付API地址
$epay_config['apiurl'] = $channel['appurl'];

//商户ID
$epay_config['pid'] = $channel['appid'];

//商户KEY
$epay_config['key'] = $channel['appkey'];
