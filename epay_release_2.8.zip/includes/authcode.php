<?php
define('authcode','');

?>